using OnlineBookStore.Models;

namespace OnlineBookStore.ViewModels;
public class BookListVm
{
    public List<Book> Books { get; set; } = new();
}
